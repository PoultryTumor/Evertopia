# Shadow Audio + Screen Enhancements (SNES backport)

Backport of the gbarecomp "verified-enhancement" QoL layer to snesrecomp.
All work lives on the `feat/shadow-enhancements` branch / `_shadow_snesrecomp`
worktree — it does not touch the in-flight `fix/apu-audio-accuracy`,
`feat/*-widescreen`, etc.

## Scope of this historical enhancement design

This document describes the existing optional presentation enhancement. Its
shadow verification rules below apply to that enhancement, not to performance
HLE replacements. New HLE/LLE work follows the shared
[HLE policy](https://github.com/mstan/recomp-ai-rules/blob/main/HLE.md): keep a
functioning LLE build, select the implementation at build time, and validate
the caller contract and measured benefit. HLE may replace load-bearing work
without simultaneously executing a reference copy.

The historical shadow enhancement was designed with these requirements:

1. The emulated (canon) path keeps running and stays both the authoritative
   output and the verify oracle. The shadow is never ground truth.
2. The shadow is continuously, differentially checked against the canon stream
   and substitutes only after a proven window.
3. It reverts loudly (logs DEGRADED) the instant it stops matching.
4. It is opt-in and present-time, off by default; with it off the output is
   byte-identical (frame hashes / verify / sweeps stay on the raw canon).

Worst-case failure is "the user hears/sees the authentic hardware output," and
it cannot mask a recompiler bug because the canon path it shadows is still the
thing being diffed. This is the rationale for that presentation feature;
it does not constrain separately built performance replacements.

## What ports verbatim vs what is SNES-specific

| Piece | Status | Notes |
|---|---|---|
| **`ShadowVerifier`** (envelope-correlation self-check, auto-gain, prove/strike/pause) | **DONE** — `runner/src/snes/audio_shadow.{c,h}`, re-implemented in C, compiles clean | Engine-agnostic; identical algorithm to gbarecomp |
| Color-science core (xyY→XYZ, primaries→matrix, Bradford, sRGB OETF) | TODO | Lifts verbatim; reused for the screen LUT |
| Present-path color LUT | **DONE (runner module)** — `runner/src/snes/color_lut.{c,h}`, in `runner.cmake`, compiles clean | PSXRecomp-aligned CIE screen models: `raw`, SMPTE-C-like `crt`, `composite`, and near-sRGB `trinitron`. Present-time `0x00RRGGBB`→graded map (5-bit recovered via >>3), selected through `SNESRECOMP_SCREEN` or the programmatic API; default `raw` is identity. Raw renderBuffer (frame-hashed oracle) is untouched. **Present hook is game-side** (the presenter lives in each game, outside this worktree) — see wiring note below |
| **S-DSP shadow render** | **DONE** — `runner/src/snes/dsp_shadow.{c,h}`, wired into `dsp_cycle`, in `runner.cmake`, compiles clean (`-Wall -Wextra`) | Cubic (Catmull-Rom) re-render of the BRR voices in float vs the hardware 4-tap Gaussian; substitutes the dry mix only when the verifier proves it, reverts loud. Opt-in `SNESRECOMP_AUDIO_SHADOW` (default off → byte-identical). Echo path unchanged (applies to the chosen dry). Verifier auto-gain absorbs scale, so only structure must match; a mis-phased render simply falls back to canon + logs DEGRADED (signal to refine the interpolation phase) |

## Integration points (found on `main`)

- **Canon audio:** `runner/src/snes/dsp.c` — `dsp_cycle()` mixes all channels →
  `totalL/totalR` → `dsp->sampleBuffer` ring (stereo, power-of-two). Per-voice
  render is `dsp_cycleChannel()` (BRR decode + Gaussian interp + ADSR →
  `ch->sampleOut`). Echo in `dsp_handleEcho()`. The host consumes native
  samples from the ring (~`dsp.c:567`). → Feed (canon, shadow) to the verifier
  per output sample; substitute the shadow into the ring only when `proven`.
- **Canon video:** `runner/src/snes/ppu.c` — `renderBuffer` (xbgr pixel
  buffer, 256×224/240). → Apply the color LUT present-time (raw stays the
  oracle).
- **Build:** per-game `CMakeLists.txt` (e.g. `SuperMarioWorldRecomp/`) pulls in
  `runner/src`. New `runner/src/snes/*.c` files must be added there (or are
  globbed — verify). Test a game build (SMW) once wiring lands.
- **Gating:** env + (eventually) per-game config, default OFF, mirroring
  gbarecomp's `GBARECOMP_AUDIO_SHADOW` / `[audio] shadow` and
  `GBARECOMP_SCREEN` / `[video] screen`.

## Next steps

1. ~~S-DSP shadow render~~ — **DONE** (see table; `dsp_shadow.{c,h}` wired).
2. ~~Color LUT~~ — **DONE** as a runner module (`color_lut.{c,h}`). Game-side
   present wiring (each game's `main.c`, outside this worktree): at startup
   call `snes_color_lut_setup()` (environment compatibility) or
   `snes_color_lut_setup_kind()` (launcher/config selection); if
   `snes_color_lut_active()`, before the
   SDL present run the finished `renderBuffer` through `snes_color_lut_map(raw,
   present_copy, w*h)` and upload the COPY (never modify the raw renderBuffer
   that gets frame-hashed). Identical shape to the GBC/Genesis present hooks.
3. Build a game (SMW) against this worktree; confirm default-off is
   byte-identical (audio + video), then A/B the enhancement. Audio compiles
   standalone; a full game build is the integration gate.
4. If the audio shadow logs DEGRADED in practice, refine the cubic phase to
   match the canon Gaussian's segment exactly (the verifier will then engage).

## Attribution

`ShadowVerifier` ported from JRickey/gba-recomp (`crates/gba-core/src/shadow.rs`)
via the gbarecomp C++ port, © Jrickey, MIT OR Apache-2.0, used with permission.

The screen-model parameterization is adapted from PSXRecomp. Exact revisions,
local adaptations, and complete PolyForm Noncommercial 1.0.0, MIT, and
Apache-2.0 notices are recorded in `third_party/psxrecomp_color_lut/` and
`THIRD_PARTY_ATTRIBUTION.md`.
