# snesrecomp Launcher — Design

Status: **SHIPPED via recomp-ui** · 2026-07-23

The pre-boot launcher is not part of the snesrecomp engine tree. Games that
need the shared Dear ImGui launcher vendor
[RetroPortingToolKit/recomp-ui](https://github.com/RetroPortingToolKit/recomp-ui) as a **repo-root**
submodule and wire it themselves. snesrecomp keeps only recomp-net (and the
lobby / netplay host facades that recomp-ui drives through callbacks).

## Integration

```cmake
# In the game repo (not snesrecomp):
#   git submodule add https://github.com/RetroPortingToolKit/recomp-ui.git recomp-ui

include(${SNESRECOMP_ROOT}/runner/runner.cmake)
add_executable(MyGame ...)

set(RECOMP_UI_ROOT "${CMAKE_SOURCE_DIR}/recomp-ui" CACHE PATH "" FORCE)
include(${RECOMP_UI_ROOT}/recomp_ui.cmake)
recomp_target_launcher_ui(MyGame)

snesrecomp_enable_recomp_net(MyGame)    # lobby + delay-sync (engine)
```

Host `main()` calls `recomp_launcher_run_window()` behind `#ifdef RECOMP_LAUNCHER`
and supplies game facts through `RecompLauncherCGameInfo` /
`launcher_profile_apply("snes", ...)`. See MetalWarriorsSNESRecomp for a
complete host.

Online lobby handoff: recomp-ui prepares `guest_bind` (prefer UDP 7778) before
`join()`; the host passes it through to `snes_lobby_join(..., guest_bind)`
(engine still normalizes NULL/empty as a fallback) and
`snes_lobby_try_fill_launch()` from `fill_launch`. See
`docs/RECOMP_NET.md` → "Lobby join / launch handoff".

Soft-return rematch (peer quit / Escape → waiting room → Play again): call
`snes_host_ensure_sdl()` + `snes_host_session_reset()` at `session_reboot`,
and `snes_netplay_soft_exit_to_lobby()` on peer leave. Checklist:
`docs/RECOMP_NET.md` → "Soft-return rematch checklist".

**Policy:** netplay + launcher interaction fixes belong in snesrecomp or
recomp-ui so every title benefits. Do not grow game `main.c` with shared
networking UX. Per-title sticky state uses `RtlGameInfo.session_reset` (and
related hooks) — see `docs/RECOMP_NET.md` → "Layering policy".

## In-game launcher (opt-in)

A title on the shared desktop host (`runner/src/desktop/host_main.c`) sets
`SnesDesktopHostGame.in_game_launcher = 1` to let the player reopen the full
launcher mid-game: `[KeyMap] OpenLauncher` (default Ctrl+L once opted in) or
`[Controller] LauncherGesture` (default Select+L3). The guest is frozen and
the game window hidden while the launcher runs in-process with
`GameInfo.in_session = 1` (RESUME instead of PLAY, a QUIT GAME button,
closing the window resumes).

On RESUME the host sorts every edit into one of two buckets:

| Applied live | Restart required |
|---|---|
| fullscreen, window scale, pixel aspect, filtering, shader, vsync, volume, frame blend, run-ahead, rewind, `[KeyMap]`, `[GamepadMap]`, `keybinds.ini`, player device | renderer / output method, audio rate, mods (`state.toml` changed), a different ROM |

A restart saves `saves/resume.sav`, shuts down completely, and starts the
executable again with `--no-launcher --resume-state <path> --rom <rom>`
(`runner/src/desktop/host_relaunch.c`); the new process loads the state before
its first frame and deletes it. A different ROM restarts from power-on.

Self-test, no human needed: `SNESRECOMP_INGAME_LAUNCHER_SELFTEST=<frame>`
opens it at that frame, recomp-ui's `LNG_SMOKE_FRAMES=<n>` closes it after n
frames (RESUME), and `SNESRECOMP_INGAME_LAUNCHER_SELFTEST_RESTART=1` takes the
restart path. The guest must come back bit-identical.

## What stayed in snesrecomp

- `runner/src/launcher.c` / `launcher.h` — shared ROM resolution policy
- `runner/src/launcher_cache.c` — executable-relative `rom.cfg` persistence
- `runner/src/launcher_picker.c` — native platform file selection
- `runner/src/rom_image_verify.c` — copier-header stripping and CRC/SHA checks
  (console-agnostic helpers used when the GUI is skipped with `--no-launcher`)
- `runner/src/rom_identity.c` — names a refused ROM from the port's catalog of
  known dumps (`SnesDesktopHostGame.rom_revisions`), describes an unknown one
  by its internal header and checksum, and recognizes archives. The launcher
  (through `GameInfo.rom_revisions` / `rom_describe`), the command-line and
  file-picker path, and mod source-ROM pickers all report from it: "This is
  Mega Man X (USA). Mega Man X needs Mega Man X (USA) (Rev 1) (SHA-256 ...)".
- Lobby / netplay backends — `snes_netplay.*`, `snes_host_session.*`,
  `snes_host_app.*`, and the SNES adapters `snes_lobby_client.*` (over
  recomp-net's lobby client) and `snes_host_lobby.*` (over recomp-ui's
  `recomp_netplay_host`), linked via `snesrecomp_enable_recomp_net`
- `lib/recomp-net` — delay-sync / ICE transport submodule

## What was removed

- Legacy GUI + FreeType submodules
- In-tree `runner/src/launcher/launcher_gui.*` and legacy markup/assets
- `tools/build_launcher_deps.ps1`
- `lib/recomp-ui` submodule and `runner/recomp_ui.cmake` (games own the UI pin)
