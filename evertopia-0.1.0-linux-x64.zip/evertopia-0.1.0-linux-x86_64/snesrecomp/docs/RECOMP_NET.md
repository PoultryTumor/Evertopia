# recomp-net (netcode)

snesrecomp vendors [recomp-net](https://github.com/RetroPortingToolKit/recomp-net)
as a git submodule at `lib/recomp-net`. Any game that builds with
`runner/runner.cmake` can link the library and drive delay-sync multiplayer
from the game main loop.

recomp-net is **opt-in**. Shipping single-player builds are unchanged unless
the game enables it.

**Rollback:** this document covers the delay-sync path, which remains the
default. The rollback admit path (`SNES_NET_MODE=rollback`, built on
`lib/retcomm-rbengine`) is documented separately in
[ROLLBACK.md](ROLLBACK.md) — including the two SNES-specific determinism
constraints a rollback host must honour and delay-sync never notices.

**More than two players:** both admit paths carry up to 8 seats when a Super
Multitap is configured. See [MULTITAP.md](MULTITAP.md) §4.

## Init the submodule

```sh
git submodule update --init --recursive lib/recomp-net
# or, for a fresh clone of snesrecomp:
git submodule update --init --recursive
```

## Enable from a game `CMakeLists.txt`

After `include(.../runner/runner.cmake)` and `add_executable(...)`:

```cmake
snesrecomp_enable_recomp_net(MyGame)
```

That `add_subdirectory`s `lib/recomp-net` once (examples/tests off) and links
`recomp_net` into the game. It also defines `SNESRECOMP_NET=1` on the target.

### Alternative: cache option

```sh
cmake -S . -B build -DSNESRECOMP_ENABLE_NET=ON
```

Then link the shared runner libs (include `recomp_net` when the option is on):

```cmake
target_link_libraries(MyGame PRIVATE
    ${SNESRECOMP_RUNNER_LIBRARIES}
    # ... SDL2, OpenGL, etc.
)
```

### ICE / WAN (optional)

LAN UDP works with the default build. For NAT traversal via libjuice:

```sh
cmake -S . -B build -DSNESRECOMP_NET_ICE=ON
# with snesrecomp_enable_recomp_net, set the cache before the helper:
#   set(SNESRECOMP_NET_ICE ON CACHE BOOL "" FORCE)
```

If libjuice is not installed or vendored, recomp-net may FetchContent it
(network required at configure time). See `lib/recomp-net/README.md`.

## Host loop (game side)

Preferred: use the SNES facade (`runner/src/netplay/snes_netplay.h`) which
`snesrecomp_enable_recomp_net` compiles into the game:

```c
#include "snes_netplay.h"

SnesNetplayConfig cfg;
snes_netplay_config_defaults(&cfg);
cfg.enabled = 1;
cfg.local_slot = launch.local_slot;
cfg.input_player = -1; /* auto — see ResolveNetplayInputPlayer in game main.c */
cfg.session_id = launch.session_id;
cfg.transport = launch.transport; /* 0 auto, 1 ICE, 2 LAN */
strncpy(cfg.bind_hostport, launch.bind_hostport, sizeof(cfg.bind_hostport) - 1);
strncpy(cfg.peer_hostport, launch.peer_hostport, sizeof(cfg.peer_hostport) - 1);
/* Resolve auto → 0/1, then start. Sample host device input_player (not slot).
 * Auto must ignore offline P2-only pad assignment so a remote guest keyboard
 * (device 0) still wraps into sim P2; host with a sole pad on P2 samples 1. */
snes_netplay_start(&cfg);

for (;;) {
    /* Prefer snes_host_barrier_admit (single-shot) + pad/event hooks.
     * On admit failure: present the held framebuffer (no RtlRunFrame /
     * draw_ppu_frame), then wall-clock pace — do not spin without present.
     * On admit success: RtlRunFrame + finish_frame; optionally burst up to
     * snes_host_catchup_budget() extra sim ticks (default 0 — resume 1:1 and
     * rebuild remote_lead toward D), then one full present.
     *
     * `snes_host_barrier_admit` latches delay-sync starvation after sustained
     * admit misses, keeps `snes_netplay_pump` (retransmit) while holding,
     * clears when `remote_lead >= D` for a few frames. Env:
     * `SNES_NET_STARVATION_ENTER_FRAMES`, `EXIT_FRAMES`, `EXIT_HR_LEAD`,
     * `SNES_NET_CATCHUP_CAP`, `SNES_NET_STARVATION_RECOVERY_BURST` (both
     * default 0). Does not invent inputs. */
    if (!snes_host_barrier_admit(from_lobby, &running, &hooks)) {
        if (!running)
            break;
        PresentHeldNetplayFrame(); /* game: SDL/GL re-present last texture */
        /* pace ~16ms; do not RtlRunFrame */
        continue;
    }
    for (int burst = 0;;) {
        RtlRunFrame(snes_netplay_published_inputs() | snes_netplay_active_mask());
        snes_netplay_finish_frame();
        if (burst >= snes_host_catchup_budget())
            break;
        snes_netplay_stage_local(local_device_buttons_12bit);
        if (!snes_netplay_poll_admit())
            break;
        burst++;
    }
    DrawPpuFrameWithPerf(); /* title-specific full present after sim */
}
```

Transport selection (`cfg.transport` / `SNES_NET_TRANSPORT`):

- **LAN** — `rnet_session_start_lan` (LAN file-registry / `SNES_NET_TRANSPORT=lan`).
  Waiting-room **Join Direct** uses UDP seat-claim (`rnet_lan_direct_*`) to the
  typed host IP:port so cross-subnet / port-forwarded peers can join; the file
  registry remains for same-machine discovery.
- **ICE** — `rnet_session_start_ice` + WS lobby `op:signal` relay
  (`snes_lobby_send_signal` / `snes_lobby_poll_signal`). Requires
  `SNESRECOMP_NET_ICE=ON` and a live lobby WebSocket (launcher keeps it across
  Launch).

**Auto policy:** a seated online WS lobby room **always** uses ICE — even when
the lobby rewrites `0.0.0.0` binds to a private TCP peer IP. That rewrite is
often wrong on hairpinned LAN paths (e.g. router `.1` instead of the peer NIC)
and must not demote hosted play to direct UDP. Pure LAN file-registry (no WS
seat) stays on LAN.

**STUN / TURN:** `snes_netplay_start` fills `RNetIceConfig` before gather:

1. Defaults: Google STUN (`stun.l.google.com:19302`).
2. WS lobby mint: after connect, client sends `get_turn_credentials`; server
   replies with Coturn STUN/TURN hosts + time-limited user/pass (see
   recomp-net-server `docs/WS_LOBBY.md` / `docs/COTURN.md`). Prefer Coturn
   STUN when present.
3. Env overrides: `SNES_NET_TURN_HOST` / `SNES_NET_TURN_USER` /
   `SNES_NET_TURN_PASS` (optional `SNES_NET_TURN_PORT`, `SNES_NET_STUN_HOST`,
   `SNES_NET_STUN_PORT`).
4. If no TURN: log **STUN-only** and continue (remote NAT may hang after a few
   frames).

ICE still ranks **host > srflx > relay** — TURN is configured up front so
libjuice can fall back to relay when hole punch is unstable. Logs include
selected candidates/addresses when ICE connects, and a concrete local IPv4
bind when `rnet_ipv4_enumerate` finds one.

**Auto TURN fallback** (recomp-net; no game change): if TURN credentials are
present and ICE was not already `force_relay`, the session restarts gather
once with relay-only candidates when:
- ICE state becomes `FAILED`, or
- ICE stays non-completed for ~12s (`RNET_ICE_RELAY_FALLBACK_MS`), or
- ICE completes on a non-relay path but no session packets arrive for ~6s
  (`RNET_ICE_RELAY_DEAD_MS`).

Peer ICE restart offers also rebuild the local agent and adopt `force_relay`
when TURN is available. Opt out: `RNET_ICE_NO_RELAY_FALLBACK=1`.

**Force TURN / relay-only ICE** (hosted server lobbies; host sets for all peers):

- **UI:** waiting-room **Lobby Settings** (under Input Delay) →
  **Force TURN / UDP Relay** (off by default). Published in lobby
  `match_caps.force_turn` so every peer applies the same ICE relay policy on
  launch. Disabled for LAN/Direct IP.
- **Env:** `SNES_NET_FORCE_TURN=1` still forces relay for this process
  (debug/override; prefer the host toggle for normal play).
- **Build (optional):** `-DSNESRECOMP_NET_FORCE_TURN=ON` forces relay for all
  ICE sessions in that binary.

Requires working Coturn mint (or `SNES_NET_TURN_*`). Refuses STUN-only ICE
start when force-TURN is on, and filters candidates to `typ relay` at runtime
(`RNetIceConfig.force_relay`) so host/srflx cannot short-circuit.

**libjuice bundling:** with `SNESRECOMP_NET_ICE=ON`, recomp-net defaults to
`RNET_ICE_BUNDLE_STATIC=ON` (FetchContent static juice linked into
`recomp_net`) so Linux game binaries do not need a distro `libjuice.so`.

### Netplay diagnostics (JSONL)

Set `SNES_NET_DIAG=1` to write `saves/netplay/net_diag.jsonl`
(rate: `SNES_NET_DIAG_HZ`, default 2; truncated each match). Line 1 is a
`type:"summary"` object with match mode (`hosted_lobby` / `direct_ip`),
lobby server URL, lobby id, input delay, TURN configured vs nominated ICE
NAT path (`ice_nat`: `host` / `stun` / `turn` / `lan`, from `ice_path`
`host|srflx|prflx|relay`), and selected addresses (`ice_local` /
`ice_remote`). Later lines are timed samples: ICE path, admit stall reason
(`wait_remote_input`, `wait_confirm`, `not_running`, …), stall wait ms,
`frames_finished` (admitted `RtlRunFrame` count), remote ring lead, peer RX
age, packet/input counters. Sampling runs inside `snes_netplay_poll_admit`
(no game-side hook required). Sample field `turn` is 1 only when the
nominated path is `relay` (not merely “TURN credentials configured”).

Input bundles must cover the full delay prefix on start (`delay+1` wire
ticks including tick 0). `RNET_MAX_BUNDLE` is 21 (max delay 20 + 1);
`send_input_bundle` also splits across multiple INPUT packets if the
window exceeds one packet — never truncate the low end of the window
(that deadlocks admit at `sim_tick==0` with `wait_remote_input`).

Rules that matter for SNES recomp hosts:

- Use `publish` / `snes_netplay_published_inputs` as the **only** pad source for
  locked ticks; do not let local-only controller reads enter the shared sim.
- Keep RNG / timers / frame pacing deterministic across peers. Pad blob bytes
  `[2..3]` carry host DP `$1A/$1B` (applied on admit) so Metal Warriors
  SCRAMBLE / NEW BATTLEFIELD rolls stay host-authoritative.
- Prefer one thread owning `pump` + sim advance (API is not internally locked).
- While `snes_netplay_active()`, the pre-frame wall-clock SPC catch-up is
  disabled. Audio stays on the runner's normal deterministic guest-frame/APU
  coupling, and the audio callback remains a consumer only; it never advances
  emulation.
- Metal Warriors netplay H2H: when dual-viewport WRAM `$1EB2` is set, each peer
  presents only its local half (slot 0 = top / P1, slot 1 = bottom / P2),
  scaled to the full window. Sim still renders the full split — present-only,
  so determinism is unchanged. Opt out with `SNESRECOMP_MW_H2H_LOCAL_VIEW=0`.
- Metal Warriors H2H present: full-frame local defaults **ON** for netplay.
  Offline uses native dual split (no local-full present). OAM `+$78` /
  vert-widen defaults **ON** for netplay (`SNESRECOMP_MW_H2H_VERT_WIDEN=0`
  to opt out); active-list Y `#$A8`→`#$E0` so tall sprites slide off instead
  of popping when the anchor crosses 168. Spawn-Y widen stays opt-in
  (`SNESRECOMP_MW_H2H_SPAWN_Y_WIDEN=1`). Both hard-off offline. BG2 stripe
  row widen (default 12 / `SNESRECOMP_MW_BG2_ROWS`) is **netplay or
  widescreen-expand only** — offline dual keeps native 8 rows so the HDMA
  center seam HUD (direction arrows) is not stomped. Keep
  `OAM_CULL` on (disabling corrupts isolated 1P/2P views). End-match results
  OAM is owned by **OBJ priority 3** (`a34`/`a35` in dumps): when ≥8 such
  sprites exist across cam buffers, present groups each cam's UI and pins by
  mean-X (native left/wins → top, right/menu → bottom; no gameplay `y_shift`,
  never cam-delta reproject). Glyph X-span split is wrong here — both
  clusters are center-stacked. Mutual raw-XY is **not** used. Opt out
  full-frame: `SNESRECOMP_MW_H2H_FULL_FRAME=0`.
- Elevator / platform probe: `SNESRECOMP_MW_ELEV=1` logs `[mw_elev]` — walks
  the `$1E14` object list (flags/X/heuristic Y + 0x20 raw bytes) plus BG1 `$7F`
  tile-patch counters, BG2 ROM-idle mask, and OAM occupancy. Flags `vw` /
  `syw` show OAM vert-widen vs spawn-Y widen. Elevator fingerprint:
  `+$08=$D5B8`, family `+$0A=$00B1`.
- End-match / results OAM probe: `SNESRECOMP_MW_RESULTS=1` logs `[mw_results]`
  (~2 Hz, dual only). Adds `ui_prio3` count alongside mutual/reproject stats.
- Metal Warriors netplay H2H Phase 2a (shared horizontal widescreen): netplay
  sessions **force** `g_ws_extra = 71` on every peer. Offline hard-disables
  widescreen for traditional split-screen local multiplayer. Lobby
  `match_caps` carry 71; the launcher hides the Widescreen toggle.
- Lobby `match_caps` (host-authoritative): create/start carry
  `{widescreen,widescreen_hud,ignore_aspect,input_delay,ws_extra,force_turn,force_input_relay}`; guests
  apply on launch and `fill_launch` fails closed online when caps are missing.
  LAN/Direct IP carries `input_delay` via the file registry (`RNET_LAN_LOBBY_2`)
  and Direct IP `START`/`CAPS` datagrams (`force_input_relay` stays 0 offline).
  Before RUNNING, recomp-net guests adopt the host's HELLO delay (slot 0).
  See `recomp-net-server/docs/WS_LOBBY.md`.
- Metal Warriors soft-return rematch: `MwSessionReset()` clears the LLE resume
  latch (`s_lle_did_reset` / resume PC / `g_cpu`) before `SnesInit`. Without
  that, rematch resumes a stale WAI on a wiped chip (`nmiEn=0`, blank).
  Autosave load/save is skipped around lobby rematch so peers cold-boot alike.
- Metal Warriors H2H Phase 2b (full-frame local): default ON for present.
  - **Present:** rebuild BG1 strips from `$7F` for the **local** camera into
    VRAM (save/restore so sim stays dual-deterministic). Present scrolls are
    forced to that camera (P1: `$1E16`/`$1E18`; P2: `$1E1A`/`$1E1C`). Stable
    half→full Y: OAM=BG `base+8`; present undoes unified emit `+$78`. Dual HDMA
    skipped. BG1 rebuild keys `$7F` from `$7E:42B3` at the **local** present
    cam. Dual sticky/`$1E36` is one shared strip — Y-walk it only when it
    shares a `$7F` column with local 42B3 (column gate). Each cam keeps a
    per-slot `$7F` snap (DMA-attributed + NMI); present prefers that cache
    and skips void writes so the non-streamed peer does not blank floors
    into sky. Opt out with `SNESRECOMP_MW_H2H_BG1_REBUILD=0` (regressive).
    BG2 `$7F` rebuild only when
    streaming; narrow idle BG2 (elevators) uses the 1P `retainHistory` +
    west-ROM path and tracks the local camera when dual BG2 WRAM mirrors are
    `$0`.
    OAM **vert-widen** (default ON; `VERT_WIDEN=0` opts out): ROM-pokes
    drawer Y `CMP` (`#$68`/`#$70`→`#$E0`, `#$FFF1`→`#$FF70`), active-list
    `#$A8`→`#$E0`, + staging `+$78` bias / cam-capture. Stage-prop anchors
    at sy≈225 are forced onto the list via pre-CMP hooks at `$809280`/
    `$8092A0` (prop-only — global `#$0100`/`#$0140` leaked P2-floor into
    cam0). Present uses local cam-capture + reprojected other-cam buffer
    (half-cull only when vert-widen is off). Capture buffer tag follows
    drawer `ADC $86/$88` (cam0) vs `ADC $8A/$8C` (cam1). Family-`$00B1`
    **mover** metas only (`$C382`/`$C39E`/`$C6A4`/`$C400`/`$C5F2`/
    `$C3EC`/`$C3C4` — not every `$00B1`≠`$D5B8`; pickups like `$9FE2`
    stay shared and are **mirrored into both cam-capture buffers** at
    commit so dual-drawer OAM pressure cannot leave a half-culled
    sprite): latch at `STA $86` /
    dual `$8087xx`; `$80882F` (pre-`TAX`) reinforces only (never clears).
    Commit recovers list object via `$96`→`$136E,Y` when tile emit
    clobbered X. Cam rebucket / hi-byte owner force **converts** `sx/sy`
    (`sy' = sy + oldCamY − newCamY`). World Y = `dest_cam+sy'` (not
    `+$04`). Object `+$06` dual-slot is **hi-byte only** (`$01xx`→P1,
    `$02xx`→P2); low-byte `$0002/$0004/$0006/$0008` on `$C382` are not
    owners. Home = hi-byte `+$06`, else nearer dual-slot mech each frame
    (4× hysteresis when both mechs exist). Unassigned (−1) until a mech
    exists. Present OAM: home peer only; X = live ± commit meta. Y =
    live+`y_shift` only (BG1-aligned — never drop `y_shift`). With
    vert-widen ON, half→full `y_bg`/`y_oam` is **0** (VW already fills
    ~224 vs `cam_raw`); a +64 recenter parked dual-bottom movers at
    `ny≥224` (brown off-strip, stripe skip_y or ~64px sky gap). Sticky
    last tile covers capture misses (sticky may default `meta_oy=−10`
    when convert miss; present does **not** force `moy==0→−10`). No
    `$7F` tile-grid OAM snap. Non-home movers blanked from local BG1 at
    live + previous trail after rebuild and again after margin prefill.
    Full-frame BG1 never falls back to `$1E36`. `$C382` = 1 OAM tile +
    BG1 body. Do **not** XY-cull gameplay/reproject near `$00B1` props
    (mechs on `$C6A4`/`$C382` vanished; A/B `OAM_CULL=0`). Commit
    recovers movers by `$82` meta match only (no loose screen-XY
    rebind). `SNESRECOMP_MW_ELEV=1`: `prop_lo`/`cap`, `bg_dy`, `skip_y`.
    Present-only; no sim bbox / `$7F` gate. Dual staging wrap at
    `CPX #$0200` needs vert-widen (`SNESRECOMP_MW_H2H_OAM_WRAP=0`
    disables). **Spawn-Y widen**
    (opt-in `SPAWN_Y_WIDEN=1`): `$82F709`/`$82F721`/`$82F733` top window +
    `$8283AC` radius +160. Default **OFF** — playtest regressed object
    lifetime and did not spawn `$D5B8` elevators. Needs
    `kInterpPreOpcodeHookSlots` ≥ ~160 (runner default 192).
    `SNESRECOMP_MW_H2H_OAM_CULL=0` disables capture present/cull. Guest 1P
    object drawer remains opt-in only (`SNESRECOMP_MW_H2H_OBJ_OAM=1`).
  - **Sim taller HDMA/stripe** (`SNESRECOMP_MW_H2H_TALLER=1`) default
    **OFF** — breaks dual split / shared strip.
  - **Top bar HUD** (default ON with full-frame): present paints a solid
    16px bar at the top of each local view (masks the top FOV transition)
    with an opponent-direction marker from dual cams. Replaces the native
    dual-seam strip that full-frame skips. Opt out:
    `SNESRECOMP_MW_H2H_TOP_BAR=0`.
  - Opt out present: `SNESRECOMP_MW_H2H_FULL_FRAME=0` (half-crop),
    `SNESRECOMP_MW_H2H_LOCAL_VIEW=0` (show split).
- **Synchronized savestate menu** (Select+R on the host; `snes_netplay_menu_*`):
  - Only the host drives it. Every peer shows its own copy of the menu; on a
    guest it is a read-only mirror that follows the host's cursor.
  - **Open** pauses every peer on the same tick: the host picks
    `sim + input delay + 16` and sends `HOLD(t)`. Each peer runs to `t` and
    stops there (rollback: `rnet_rb_driver_set_hold` admits nothing at or past
    `t` and predicts nothing while held, so `t` is final once reached; the
    local pad is neutral and unsealed while the menu is up). When every peer
    has answered `SETTLE`, the host probes the size and CRC of its snapshot at
    `t`; a guest whose own snapshot differs is sent the host's, and every peer
    -- the host too -- applies those same bytes. The snapshot is the rollback
    format (`RtlNetplaySnapshotToMemory`): a plain savestate lacks the timing
    residue, and a guest given only that kept its own residue and the resumed
    match refused on the APU digest. The S-DSP output ring (advanced by the
    audio thread) is blanked while writing and the residue's absolute cycle
    counters are left out of the CRC (`RtlNetplaySnapshotHashedBytes`), so two
    peers in one state agree with audio on. Menu saves blank the ring too.
  - **Save**: every peer writes the slot (and its thumbnail) itself, then the
    host probes the file's CRC; only a peer whose copy differs is sent the
    host's slot and thumbnail (`state_drop_peer` removes the matching seats).
  - **Load**: the slot is probed and sent the same way first; then `LOAD`
    has every peer apply its own verified copy, and the menu closes.
  - **Close** sends `RESUME`. If no peer's state was replaced the hold is
    released and play continues in the same rollback epoch. Otherwise (a
    load, or a pause state that had to be sent) `RESYNC` first clears every
    peer's input rings, then `RESUME` primes and restarts the epoch -- in
    that order, because a peer that cleared after another had primed would
    erase the primed wires and wait on them forever.
  - Commands are size-0 probes on slot 255 (`crc = cmd << 28 | arg`), one at a
    time; every guest replies after acting. A paused match stays connected
    (validated with 10 s holds).
  - Test: `tools/test_netplay_desktop.py --savestate-menu` in the MMX port
    (`--force-mismatch` diverges the guest once so the repair path runs;
    `--delay-sync`, `--menu-hold-ms`).
- Hotkey savestate / SRAM during netplay is **host-only** (`local_slot == 0`):
  - **Host** keeps personal files under `saves/` (continuous). Save/load and
    SRAM flush apply **immediately** on the host; the blob is then shipped
    async to the guest (`STATE_*` chunks). Load/SRAM stall admit until the
    guest catches up; save does not stall the sim.
  - **Guest** redirects `RtlSaveRoot()` to `saves/netplay/` so host-driven
    mirrors never overwrite personal `saves/save.srm` / `saveN.sav`. On
    session end the sandbox is flushed, `g_sram` is cleared, then personal
    SRAM is re-read (missing file → blank cart RAM). That prevents a later
    `RtlWriteSram()` under `saves/` from leaking host progress into offline
    storage when the guest had no prior save file.
  - On match start the host syncs live battery SRAM so both peers share the
    same cart RAM for the session.

Low-level API: `lib/recomp-net/docs/host_integration.md`.

## Lobby join / launch handoff (server-hosted)

Port policy is split so games do not each reimplement it:

| Step | Owner | Behavior |
|------|--------|----------|
| Host **create** UDP port | recomp-ui (`launcher_udp_port.*`) | LAN: exact port; online: scan preferred..+31 and rewrite endpoint before `create()` |
| Guest **join** UDP bind | recomp-ui (`launcher_udp_prepare_guest_bind`) | Prefer 7778..7809 → `0.0.0.0:<port>` passed through `join()`; `snes_lobby_join` still normalizes NULL/empty/`host:0` as a safety net (never advertise `:0`) |
| **fill_launch** | snesrecomp (`snes_lobby_try_fill_launch`) | Returns 1 only after `op:launch` with usable bind/peer; wire from `RecompLauncherCNetplayCallbacks.fill_launch` |

```c
/* Online join — guest_bind from recomp-ui join() callback (prefer 7778). */
snes_lobby_join(lobby_id, password, guest_bind);

/* fill_launch callback: */
SnesLobbyJoinInfo join;
if (!snes_lobby_try_fill_launch(&join)) return 0;
/* copy join.bind_hostport / peer_hostport / session_id / local_slot → out */
```

## Engine host scaffold (`snes_host_*`)

Shared MotK + LAN lobby + rematch primitives are linked by
`snesrecomp_enable_recomp_net`. Games should **not** copy lobby callback
tables or soft-return glue.

**Where the lobby lives (lifted 2026-09-25).** The two big pieces are no
longer SNES code:

| Was | Now | SNES side |
|-----|-----|-----------|
| `runner/src/lobby/snes_lobby_client.c` (4,653 lines) + vendored `lobby/ws/` | recomp-net `recomp_net/lobby_client.h`, `src/lobby/rnet_lobby_client.c` (+ its `lobby_ws`) | `snes_lobby_client.{h,c}`: the old names, `SnesLobbyMatchCaps` with its widescreen fields (carried as SNES keys through recomp-net's caps codec), `SNES_NET_` env alias |
| `runner/src/netplay/snes_host_lobby.c` (2,967 lines) | recomp-ui `src/recomp_netplay_host.h` / `src/netplay/recomp_netplay_host.c` (optional target `recomp_launcher_netplay`) | `snes_host_lobby.c`: identity/opts → hooks, widescreen settlement, the mod runtime as mod hooks, the rollback fork report |

So the port needs a recomp-ui that carries `recomp_target_launcher_netplay()`
(configure fails naming it otherwise), included before
`snesrecomp_enable_recomp_net`. The `snes_host_lobby_*` / `snes_lobby_*` API
the ports call is unchanged. Environment: `RNET_LOBBY_URL` /
`RNET_LOBBY_GAME_VERSION` are the generic names; `SNES_NET_LOBBY_URL` /
`SNES_NET_GAME_VERSION` still work (the generic name wins when both are set);
`RECOMP_NETPLAY_LIST_DEBUG` beside `SNESRECOMP_LOBBY_LIST_DEBUG`.

Known SNES gap, stated where it bites: session slots stay seat-mapped
(`RECOMP_NETPLAY_SLOTS_SEAT`) because the engine does not read
`launch.slot_port[]` yet, so a host who moved to seat 1 is session slot 1
here, not slot 0 as recomp-ui's HOST_NETPLAY.md contract asks.

| API | Role |
|-----|------|
| `snes_host_lobby_init` / `snes_host_lobby_callbacks` | SNES adapter over recomp-ui's `recomp_netplay_host` (MotK WS + LAN) for `RecompLauncherCGameInfo.netplay` |
| `snes_host_lobby_prepare_rematch` / `snes_host_app_begin_soft_return` | Soft-return waiting-room prep |
| `snes_host_lobby_set_runtime_error` | Waiting-room error string after a failed session |
| `snes_host_app_apply_launch` | Map `RecompLauncherCNetplayLaunch` → `SnesNetplayConfig` |
| `snes_host_ensure_sdl` / `snes_host_session_reset` | Rematch SDL + `RtlGameInfo.session_reset` |
| `snes_netplay_soft_exit_to_lobby` | Escape / peer BYE → lobby |
| `snes_host_barrier_admit` | Shared MotK admit loop (pad / SDL poll / modal remain game hooks) |
| `snes_netplay_connect_wait_*` | Session-scoped connect-wait clock (reset on start / shutdown / soft-exit) |

Minimal game wiring:

```c
SnesHostLobbyIdentity id = {
  .game_name = "My Game",
  .game_version = SNES_GAME_VERSION,
  .lan_registry_path = "netplay_lan_lobby.txt",
};
SnesHostLobbyOpts opts = { .rematch_set_ready = 1, .fill_match_caps = MyCaps };
snes_host_lobby_init(&id, &opts);
gi.netplay = snes_host_lobby_callbacks();

/* session_reboot: */
snes_host_ensure_sdl();
snes_host_session_reset(); /* → RtlGameInfo.session_reset */

/* after match soft-return: */
snes_host_app_begin_soft_return(&gi, /*set_resume_room=*/1);
/* recomp_launcher_run_window(...); then snes_host_app_apply_launch(...) */
```

Reference consumers:
- MetalWarriorsSNESRecomp `src/main.c` (lobby table removed)
- SuperMarioWorldRecomp Co-op `src/smw_netplay_lobby.c` (thin identity + AutoLaunch only)

### Per-game patches that stay in the title (checklist)

Bump snesrecomp + recomp-ui first. Then each netplay host still needs these
**small** game-side pieces — document new items here rather than growing
another lobby copy:

| Patch | Where | Notes |
|-------|--------|-------|
| `snes_host_lobby_init` identity | Game once | `game_name`, `game_version`, LAN path, `default_lobby_name` |
| `SnesHostLobbyOpts` | Game once | `auto_ready_guests` (SMW=1), `rematch_set_ready` (MW=1 / SMW=0), `fill_match_caps` |
| `fill_match_caps` | Game | Widescreen / `ws_extra` / delay policy (MW `ws_extra=71`; SMW forces WS off) |
| `gi.netplay = snes_host_lobby_callbacks()` | Launcher open + soft-return | Prefer engine table; thin wrappers OK |
| Soft-return reopen | After match | `snes_host_app_begin_soft_return(&gi, 1)` then `recomp_launcher_run_window` |
| Rematch `session_reboot` | Host loop | `snes_host_ensure_sdl()` + `snes_host_session_reset()` |
| `RtlGameInfo.session_reset` | CPU infra / RTL | Clear sticky LLE / frame gates / rematch latches (`MwSessionReset`, `SmwSessionReset`) |
| Pad sample + `RtlRunFrame` gate | Host loop | Prefer `snes_host_barrier_admit` (single-shot) + pad/event hooks — stall → held present; admit → sim (+ optional `snes_host_catchup_budget`, default 0) — do not copy admit loops |
| Connect-timeout modal | Host hook | `on_connect_timeout` only (message/UI). Clock is engine-owned — never a game `static` timer |
| Runtime error into waiting room | Optional | `snes_host_lobby_set_runtime_error` (SMW uses this) |
| ROM keep vs reload | Host loop | Title policy (free/`kRom` rematch path, CRC/SHA checks) |
| Offline Play after soft-return | Host loop | `LAUNCH && !net.enabled` → disconnect + `session_reboot` |
| Game CMake feature flag | CMake | e.g. `SMW_COOP_BUILD`, `snesrecomp_enable_recomp_net` |
| Self-test AutoLaunch | Optional | `snes_host_lobby_auto_launch` (thin game wrapper OK) |

Do **not** re-copy MotK create/join/`fill_launch` / LAN file-registry glue into
games — or into engines: it lives in recomp-ui's `recomp_netplay_host.c`, and
`snes_host_lobby.c` is the SNES adapter over it.

## Layering policy (prefer engine / UI over game trees)

**Default:** put networking optimizations and launcher/netplay UX fixes in
**snesrecomp** (`snes_netplay_*`, `snes_lobby_*`, `snes_host_*`) or
**[recomp-ui](https://github.com/RetroPortingToolKit/recomp-ui)** (presentation, UDP port
prep, waiting-room flow) — **not** as one-off patches in each game’s
`main.c` / RTL. New titles then inherit the fix when they bump submodules.

**Game trees stay thin:** wire callbacks, sample pads, gate `RtlRunFrame`, and
register per-title hooks. Avoid copying soft-return / SDL rematch / guest-bind
logic between Metal Warriors, SMW Co-op, etc.

**Per-title behavior** uses existing snesrecomp extension points — do **not**
fork the shared helpers for one ROM:

| Mechanism | Use for |
|-----------|---------|
| `RtlGameInfo.session_reset` | Sticky LLE / frame gates / widescreen latches cleared on rematch (`MwSessionReset`, `SmwSessionReset`) |
| `RtlGameInfo.state_*_extra` / `on_state_loaded` | Savestate LLE chunks and post-load reconcile |
| `RtlGameInfo.title` + env / match_caps | Title-keyed policy already in lobby / host facades |
| Game `CMakeLists` flags (e.g. `SMW_COOP_BUILD`) | Optional features that change which host binary links netplay |

If a change is truly ROM-specific but still belongs in the engine (shared
runner path), gate it on `g_rtl_game_info->title` or a small `RtlGameInfo`
callback — same pattern as savestate extras — so it stays locked to that
title without living in the game repo.

recomp-ui policy mirror: `docs/HOST_NETPLAY.md` → “Where to put fixes”.

## What snesrecomp does vs. what the game does

| Layer                                                                          | Responsibility                                                                 |
| ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| snesrecomp (`lib/recomp-net`, `snes_netplay`, `snes_host_session`, lobby)     | Vendors netcode, pad/admit facade, MotK WS + ICE; guest bind normalize; `try_fill_launch`; rematch SDL ensure + soft-exit + `session_reset` dispatch |
| [recomp-ui](https://github.com/RetroPortingToolKit/recomp-ui)                                | Waiting-room UI, UDP create/join port prep (`guest_bind`), resume-room flags   |
| Game runtime                                                                   | Thin callbacks → helpers above; `RtlGameInfo` hooks; pad sample / `RtlRunFrame` |
| [recomp-net-server](https://github.com/RetroPortingToolKit/recomp-net-server) | Lobby membership, launch, ICE signal relay                                     |

## Windows MSBuild / `lib/` superbuild

CMake game builds should use `snesrecomp_enable_recomp_net` (above).

To also build `recomp_net.lib` from the launcher dep superbuild:

```sh
cmake -S lib -B lib/_build -DSNESRECOMP_BUILD_RECOMP_NET=ON
cmake --build lib/_build --target recomp_net
```

Hand-maintained `.vcxproj` games must add the include path
`snesrecomp/lib/recomp-net/include` and link the resulting static library
themselves (same pattern as other optional runner libs).

## Soft-return rematch checklist (game hosts)

Titles that soft-return to recomp-ui after a match (Escape / window close /
peer leave) and then **Play** again share one process. Prefer the **shared
helpers** below; only title sticky state stays in the game via
`RtlGameInfo.session_reset`.

### 1. `join()` ABI — pass UI `guest_bind`

```c
int (*join)(void *ctx, const char *lobby_id, const char *password,
            char *guest_bind /* in/out, capacity >= 64 */);
```

recomp-ui fills `guest_bind` (prefer `7778`..) before calling. Online hosts
**must** pass that buffer to `snes_lobby_join(..., guest_bind)`. Passing
`NULL`/ignoring it used to advertise `peer_ip:0`; the engine still normalizes
that as a safety net, but the UI bind is the contract. LAN file-registry joins
may ignore `guest_bind`.

Member rows: use `snes_lobby_member_is_host(&member)` (not `slot == 0`).

### 2. Peer disconnect → soft lobby return, no modal

```c
snes_netplay_soft_exit_to_lobby("peer_disconnect", /*from_lobby=*/1);
```

Same path as Escape / `SDL_QUIT` (via `snes_host_barrier_admit` hooks).
Do **not** show `SDL_ShowSimpleMessageBox` for mid-match peer loss. Keep
modals for **connect timeouts** (`on_connect_timeout` only).

Connect-wait time lives in `snes_netplay_connect_timed_out` and is reset on
`snes_netplay_start` / `shutdown` / soft-exit. Games must **not** keep a
`static` wait clock across rematch — that caused instant false
`connect_timeout_lan` after Escape → soft-return → Play.

### 2a. A refused match soft-returns the same way

The rollback driver refuses a match whose peers did not boot the same
(`boot_digest_mismatch`) or do not run the same mods (`mod_set_mismatch`,
`mod_set_not_agreed`). It then admits no further tick and raises the
return-to-lobby request with the session still up. `snes_host_barrier_admit`
is the consumer: it logs `snes_netplay: match refused (<code>) at sim=N`,
puts the code in the launcher's `last_error` (`snes_host_lobby_set_runtime_error`)
and takes the same soft exit as a peer leaving, so `*running` drops to 0 and a
lobby match comes back to the waiting room. A host that pumps admission
through `snes_host_barrier_admit` needs nothing more; one that polls
`snes_netplay_poll_admit` itself must check `snes_netplay_return_to_lobby_requested()`
while `snes_netplay_active()` and leave, reading `snes_netplay_refusal()`
first. Until 2026-09-25 nothing in the runner read the request: the desktop
host's loop (`host_main.c`) never checks it, so by reading it plays a refused
match on (not run -- no desktop-host port here builds netplay), and only game
hosts that had copied the check (Gundam, Metal Warriors `main.c`) left, without
saying why. Proven two-process on Gundam with `SNES_RB_FORCE_BOOT_FORK=1` and
`SNES_RB_FORCE_MOD_MISMATCH=1` on one peer: both peers log the refusal and
leave within ~0.7 s of the second one starting.

### 3. Re-init SDL + session_reset on rematch

recomp-ui's `launcher_platform_close()` calls **`SDL_Quit()`**. At
`session_reboot:` (before window / audio):

```c
if (snes_host_ensure_sdl() != 0)
  return 1;
snes_host_session_reset(); /* → RtlGameInfo.session_reset if set */
```

Register the title hook once:

```c
const RtlGameInfo kGameInfo = {
  /* ... */
  .session_reset = &MyGameSessionReset, /* clears LLE / g_did_reset / etc. */
};
```

Symptom without SDL ensure: `Audio subsystem is not initialized`.

### 4. Cold-boot the emulation session on rematch

Soft-return keeps lobby WebSocket state; the **emulation** session must still
be a cold boot on both peers:

- Free / recreate `Snes`; sticky clears live in `session_reset` (above).
- Skip autosave load/save around rematch so peers do not diverge.
- Re-arm netplay from the new `RecompLauncherCNetplayLaunch` before
  `snes_netplay_start`.

### 5. Offline Play after soft-return must `session_reboot`

The post-match `recomp_launcher_run_window` can return **LAUNCH** with
`netplay_launch.enabled == 0`. That is still a launch — disconnect the lobby,
clear `g_netplay_pending`, and `goto session_reboot`. Do **not** treat
“LAUNCH && !net.enabled” as quit.

### Reference hosts

| Title | Soft-return + rematch |
|-------|------------------------|
| MetalWarriorsSNESRecomp | `snes_host_lobby_*` + `session_reboot` + `MwSessionReset` |
| SuperMarioWorldRecomp (`SMW_COOP_BUILD`) | thin `smw_netplay_lobby.c` → same helpers + `SmwSessionReset` |

Also see `docs/LAUNCHER_DESIGN.md` and recomp-ui `docs/HOST_NETPLAY.md`.
