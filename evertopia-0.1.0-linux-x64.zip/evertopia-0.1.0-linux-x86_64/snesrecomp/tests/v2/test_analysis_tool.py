"""Whole-program analysis through the native analyzer: manifest contracts.

The exit-equation solver's unit tests live beside it in
recompiler-rs/src/bin/analyze.rs.
"""

import pathlib
import sys
import tempfile

from _helpers import make_lorom_bank0  # noqa: E402

REPO = pathlib.Path(__file__).resolve().parent.parent.parent
if str(REPO / "tools") not in sys.path:
    sys.path.insert(0, str(REPO / "tools"))

from v2_analyze import _load_cfgs, build_manifest_native  # noqa: E402
from v2.program_analysis import NodeDisposition, VariantKey  # noqa: E402
from v2.program_emit import build_emission_entries  # noqa: E402


def analyze(rom, parsed, *, max_insns=4096, max_nodes=100_000,
            all_cfg_roots=False):
    """Run the native analyzer on `rom` against the cfg dir `parsed` came from."""
    cfg_dir = parsed[0][1].parent
    rom_path = cfg_dir / "fixture.sfc"
    rom_path.write_bytes(rom)
    manifest, helpers, inline, _output = build_manifest_native(
        rom_path=rom_path, cfg_dir=cfg_dir, all_cfg_roots=all_cfg_roots,
        max_insns=max_insns, max_nodes=max_nodes)
    return manifest, helpers, inline


def test_manifest_from_cfg_roots_is_stable_and_follows_calls():
    rom = make_lorom_bank0({
        0x8000: bytes([0x20, 0x00, 0x90, 0x60]),
        0x9000: bytes([0x60]),
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\nfunc Root 8000 end:8004 entry_mx:1,0\n",
            encoding="utf-8")
        first, first_helpers, first_inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)
        second, second_helpers, second_inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    assert first.to_json() == second.to_json()
    assert len(first.roots) == 1
    assert len(first.nodes) == 2
    assert not first_helpers and not second_helpers
    assert not first_inline and not second_inline


def test_ptrcall_dispatch_target_is_a_root_with_proven_exits():
    rom = make_lorom_bank0({
        0x8000: bytes([0xF4, 0x08, 0x80, 0x6C, 0x10, 0x00]),
        0x8009: bytes([0x60]),
        0x8010: bytes([0x60]),
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "indirect_dispatch 8003 1 ptrcall targets:8010\n"
            "func Root 8000 end:800a entry_mx:1,1\n"
            "func Handler 8010 end:8011 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), all_cfg_roots=True)

    root = VariantKey(0x008000, 1, 1)
    handler = VariantKey(0x008010, 1, 1)
    assert manifest.roots == (root, handler)
    assert set(manifest.nodes) == {root, handler}
    assert manifest.exit_modes == {root: (1, 1), handler: (1, 1)}
    assert not manifest.exit_mode_sets
    assert all(node.disposition == NodeDisposition.AOT_ELIGIBLE
               for node in manifest.nodes.values())


def test_native_poisoned_callee_does_not_publish_false_noreturn_fact():
    """An undecodable target is unknown, not a proven non-returning callee."""
    rom = make_lorom_bank0({
        0x8000: bytes([0x22, 0x00, 0x80, 0x7F, 0x60]),
    })
    with tempfile.TemporaryDirectory() as directory:
        root = pathlib.Path(directory)
        cfg_dir = root / "cfg"
        cfg_dir.mkdir()
        rom_path = root / "fixture.sfc"
        rom_path.write_bytes(rom)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func Root 8000 end:8005 entry_mx:1,1\n",
            encoding="utf-8")
        (cfg_dir / "bank7f.cfg").write_text(
            "bank = 7f\n"
            "func Poison 8000 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline, _output = build_manifest_native(
            rom_path=rom_path, cfg_dir=cfg_dir, all_cfg_roots=True)

    root_key = VariantKey(0x008000, 1, 1)
    poisoned_key = VariantKey(0x7F8000, 1, 1)
    assert manifest.nodes[poisoned_key].disposition == NodeDisposition.LLE_ONLY
    assert "structural_poison" in manifest.nodes[poisoned_key].reasons
    assert poisoned_key not in manifest.exit_mode_sets
    assert root_key not in manifest.exit_mode_sets


def test_default_roots_are_vectors_not_every_function_boundary():
    image = bytearray(make_lorom_bank0({
        0x8000: bytes([0x20, 0x00, 0x90, 0x60]),
        0x9000: bytes([0x60]),
        0xA000: bytes([0x60]),
    }))
    # Native NMI, native IRQ, emulation RESET.
    image[0x7FEA:0x7FEC] = bytes([0x00, 0x80])
    image[0x7FEE:0x7FF0] = bytes([0x00, 0x80])
    image[0x7FFC:0x7FFE] = bytes([0x00, 0x80])
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func VectorBody 8000 end:8004\n"
            "func ReachedBoundary 9000 end:9001\n"
            "func UnreachableBoundary a000 end:a001\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            bytes(image), _load_cfgs(cfg_dir),
            max_insns=128, max_nodes=128)

    assert len(manifest.roots) == 4  # RESET M1X1 overlaps NMI/IRQ M1X1.
    assert {key.pc24 for key in manifest.nodes} == {0x008000, 0x009000}
    assert all(key.pc24 != 0x00A000 for key in manifest.nodes)


def test_reachable_exit_mx_fixed_point_redecodes_caller_continuation():
    # Callee forces 16-bit X.  The caller's LDX immediate is therefore three
    # bytes after return; preserve-by-default would decode only two and walk
    # into the $12 operand as an opcode.
    rom = make_lorom_bank0({
        0x8000: bytes([
            0x20, 0x00, 0x90,       # JSR $9000
            0xA2, 0x34, 0x12,       # LDX #$1234 (X=0 after callee)
            0x60,
        ]),
        0x9000: bytes([0xC2, 0x10, 0x60]),  # REP #$10; RTS
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func Root 8000 end:8007 entry_mx:1,1\n"
            "func ForceX16 9000 end:9003 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    assert manifest.exit_modes[
        next(key for key in manifest.exit_modes
             if key.pc24 == 0x009000 and (key.m, key.x) == (1, 1))
    ] == (1, 0)
    root = next(node for key, node in manifest.nodes.items()
                if key.pc24 == 0x008000 and (key.m, key.x) == (1, 1))
    assert root.max_pc24 == 0x008006
    assert all("brk_at" not in reason for reason in root.reasons)
    assert root.disposition == NodeDisposition.AOT_ELIGIBLE


def test_proven_noreturn_callee_leaves_caller_to_lle():
    rom = make_lorom_bank0({
        0x8000: bytes([0x20, 0x00, 0x90, 0x00]),  # JSR $9000; dead BRK
        0x9000: bytes([0xCB]),                    # WAI: no return path
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func Root 8000 end:8004 entry_mx:1,1\n"
            "func WaitForever 9000 end:9001 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    root_key = VariantKey(0x008000, 1, 1)
    wait_key = VariantKey(0x009000, 1, 1)
    assert manifest.exit_mode_sets[wait_key] == frozenset()
    # The caller's empty proof is conditional on the proven-empty callee.
    # Retaining that validated SCC requirement prevents publish/invalidate
    # oscillation; an exit proof still does not authorize AOT emission.
    assert manifest.exit_mode_sets[root_key] == frozenset()
    assert root_key not in manifest.exit_modes
    # The JSR has no decoded continuation, so AOT would have nothing to resume
    # if the callee ever yields back; LLE owns the caller (native analyzer
    # rule since 9b52008, nonterminal_call_leaf_is_not_aot_safe).
    assert manifest.nodes[root_key].disposition == NodeDisposition.LLE_ONLY
    assert "truncated_call_continuation" in manifest.nodes[root_key].reasons
    assert manifest.nodes[root_key].max_pc24 == 0x008000


def test_recursive_unknown_exit_component_converges_to_lle():
    rom = make_lorom_bank0({
        0x8000: bytes([
            0x20, 0x00, 0x90,       # JSR $9000
            0x60,                   # RTS
        ]),
        0x9000: bytes([
            0x20, 0x00, 0x80,       # JSR $8000
            0xC2, 0x20,             # REP #$20
            0x60,                   # RTS
        ]),
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func RecursiveA 8000 end:8004 entry_mx:1,1\n"
            "func RecursiveB 9000 end:9006 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    assert not manifest.exit_modes
    assert len(manifest.nodes) == 2
    assert all(node.disposition == NodeDisposition.LLE_ONLY
               for node in manifest.nodes.values())
    assert all("unproven_callee_exit" in node.reasons
               for node in manifest.nodes.values())


def test_recursive_preservation_proof_survives_truncated_round():
    # Each routine has a concrete local return and a mutually recursive path.
    # The first strict decode stops at the unknown call, while the preservation
    # probe exposes the post-call RTS. The closed SCC proves both exits M1X1;
    # that proof must survive the same round's stale truncated-node summary.
    rom = make_lorom_bank0({
        0x8000: bytes([
            0xA5, 0x00,             # LDA $00
            0xF0, 0x04,             # BEQ local RTS
            0x20, 0x00, 0x90,       # JSR $9000
            0x60,                   # post-call RTS
            0x60,                   # local RTS
        ]),
        0x9000: bytes([
            0xA5, 0x00,             # LDA $00
            0xF0, 0x04,             # BEQ local RTS
            0x20, 0x00, 0x80,       # JSR $8000
            0x60,                   # post-call RTS
            0x60,                   # local RTS
        ]),
    })
    with tempfile.TemporaryDirectory() as directory:
        root = pathlib.Path(directory)
        cfg_dir = root / "cfg"
        cfg_dir.mkdir()
        rom_path = root / "fixture.sfc"
        rom_path.write_bytes(rom)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func RecursiveA 8000 end:8009 entry_mx:1,1\n"
            "func RecursiveB 9000 end:9009 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    for pc24 in (0x008000, 0x009000):
        key = VariantKey(pc24, 1, 1)
        assert manifest.exit_modes[key] == (1, 1)
        assert manifest.nodes[key].disposition == NodeDisposition.AOT_ELIGIBLE


def test_lorom_mirror_uses_declared_function_boundaries():
    rom = make_lorom_bank0({
        0x8000: bytes([0x5C, 0x00, 0x81, 0x80]),  # JML $80:8100
        0x8100: bytes([0x4C, 0x00, 0x82]),        # JMP $8200
        0x8200: bytes([0x60]),                    # RTS
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func Root 8000 end:8004 entry_mx:1,1\n"
            "func MirroredTarget 8100 end:8103 entry_mx:1,1\n"
            "func MirroredSibling 8200 end:8201 entry_mx:1,1\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    mirrored = manifest.nodes[next(
        key for key in manifest.nodes
        if key.pc24 == 0x808100 and (key.m, key.x) == (1, 1))]
    assert mirrored.instruction_count == 1
    assert any(edge.target is not None
               and edge.target.pc24 == 0x808200
               for edge in mirrored.demands)


def test_hle_overlay_preserves_entry_mx_for_caller_analysis():
    rom = make_lorom_bank0({
        0x8000: bytes([0x20, 0x00, 0x90, 0x60]),  # JSR $9000; RTS
        # The ROM body is a non-returning scheduler transfer. The HLE overlay
        # is the callable boundary and therefore uses the preserve-M/X ABI.
        0x9000: bytes([0x80, 0xFE]),              # BRA $9000
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func Root 8000 end:8004 entry_mx:1,1\n"
            "func YieldOverlay 9000 end:9002 entry_mx:1,1\n"
            "hle_func 9000 HleYieldOverlay\n",
            encoding="utf-8")
        manifest, _helpers, _inline = analyze(
            rom, _load_cfgs(cfg_dir), max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    root_key = next(key for key in manifest.nodes
                    if key.pc24 == 0x008000 and (key.m, key.x) == (1, 1))
    assert manifest.nodes[root_key].disposition == NodeDisposition.AOT_ELIGIBLE
    assert manifest.exit_modes[root_key] == (1, 1)


def test_hle_overlay_contract_applies_to_lorom_execution_mirror():
    rom = make_lorom_bank0({
        0x8000: bytes([0x5C, 0x00, 0x81, 0x80]),  # JML $80:8100
        0x8100: bytes([0x20, 0x00, 0x90, 0x60]),  # JSR $9000; RTS
        0x9000: bytes([0x80, 0xFE]),              # BRA $9000
    })
    with tempfile.TemporaryDirectory() as directory:
        cfg_dir = pathlib.Path(directory)
        (cfg_dir / "bank00.cfg").write_text(
            "bank = 00\n"
            "func Root 8000 end:8004 entry_mx:1,1\n"
            "func MirroredCaller 8100 end:8104 entry_mx:1,1\n"
            "func YieldOverlay 9000 end:9002 entry_mx:1,1\n"
            "hle_func 9000 HleYieldOverlay\n",
            encoding="utf-8")
        parsed = _load_cfgs(cfg_dir)
        manifest, _helpers, _inline = analyze(
            rom, parsed, max_insns=128, max_nodes=128,
            all_cfg_roots=True)

    caller_key = next(key for key in manifest.nodes
                      if key.pc24 == 0x808100
                      and (key.m, key.x) == (1, 1))
    assert manifest.nodes[caller_key].disposition == NodeDisposition.AOT_ELIGIBLE
    assert manifest.exit_modes[caller_key] == (1, 1)
    entries_by_bank, emitted, _names, _cfgs = build_emission_entries(
        manifest, parsed)
    assert emitted[0x809000] == {
        (0, 0), (0, 1), (1, 0), (1, 1)
    }
    assert {
        (entry.entry_m, entry.entry_x)
        for entry in entries_by_bank[0x80]
        if entry.start == 0x9000
    } == {(0, 0), (0, 1), (1, 0), (1, 1)}
