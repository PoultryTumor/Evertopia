"""LLE-first compact whole-program analysis regressions (native analyzer).

Content changes that leave the manifest untouched are covered where they are
consumed: test_program_emit.test_rom_change_regenerates_banks_in_place.
"""

import json
import pathlib
import sys
import tempfile

from _helpers import make_lorom_bank0  # noqa: E402

REPO = pathlib.Path(__file__).resolve().parent.parent.parent
if str(REPO / "tools") not in sys.path:
    sys.path.insert(0, str(REPO / "tools"))

from v2_analyze import build_manifest_native  # noqa: E402
from v2.program_analysis import (  # noqa: E402
    EdgeKind,
    EdgeResolution,
    NodeDisposition,
    ProgramManifest,
    VariantKey,
)


def _analyze(rom, cfg_lines, *, max_insns=12000):
    """Analyze `rom` with bank-0 cfg `cfg_lines`; every func is a root."""
    with tempfile.TemporaryDirectory() as directory:
        root = pathlib.Path(directory)
        (root / "bank00.cfg").write_text(
            "bank = 00\n" + "".join(line + "\n" for line in cfg_lines),
            encoding="utf-8")
        rom_path = root / "fixture.sfc"
        rom_path.write_bytes(rom)
        manifest, _helpers, _inline, _output = build_manifest_native(
            rom_path=rom_path, cfg_dir=root, all_cfg_roots=True,
            max_insns=max_insns)
    return manifest


def test_direct_call_closure_preserves_exact_mx_and_is_deterministic():
    rom = make_lorom_bank0({
        0x8000: bytes([0x20, 0x00, 0x90, 0x60]),  # JSR $9000; RTS
        0x9000: bytes([0x60]),
    })
    cfg = ["func Root 8000 entry_mx:1,0"]
    manifest = _analyze(rom, cfg)

    assert sorted(manifest.nodes) == [
        VariantKey(0x008000, 1, 0), VariantKey(0x009000, 1, 0)]
    edge, = manifest.nodes[VariantKey(0x008000, 1, 0)].demands
    assert edge.kind == EdgeKind.DIRECT_CALL
    assert edge.resolution == EdgeResolution.AOT_EXACT
    assert edge.target == VariantKey(0x009000, 1, 0)
    assert manifest.to_json() == _analyze(rom, cfg).to_json()
    assert list(json.loads(manifest.to_json())["nodes"]) == [
        "008000:M1X0", "009000:M1X0"]


def test_manifest_wire_format_round_trips_and_ignores_backend_metadata():
    rom = make_lorom_bank0({0x8000: bytes([0x60])})
    manifest = _analyze(rom, ["func Root 8000 entry_mx:1,1"])
    value = json.loads(manifest.to_json())
    value["native_analysis"] = {"dispatch_helpers": {}, "inline_args": {}}

    restored = ProgramManifest.from_dict(value)

    assert restored.to_dict() == manifest.to_dict()


def test_unresolved_indirect_is_per_edge_lle_and_keeps_direct_demand():
    rom = make_lorom_bank0({
        0x8000: bytes([
            0x20, 0x00, 0x90,  # JSR $9000
            0x6C, 0x10, 0x00,  # JMP ($0010), unresolved runtime pointer
        ]),
        0x9000: bytes([0x60]),
    })
    manifest = _analyze(rom, ["func Root 8000 entry_mx:1,1"])
    root = manifest.nodes[VariantKey(0x008000, 1, 1)]

    assert root.disposition == NodeDisposition.AOT_ELIGIBLE
    assert "has_lle_indirect_edge" in root.reasons
    assert {edge.kind for edge in root.demands} == {
        EdgeKind.DIRECT_CALL, EdgeKind.UNRESOLVED_INDIRECT}
    dynamic = next(edge for edge in root.demands
                   if edge.kind == EdgeKind.UNRESOLVED_INDIRECT)
    assert dynamic.resolution == EdgeResolution.LLE_DYNAMIC
    assert dynamic.target is None
    assert VariantKey(0x009000, 1, 1) in manifest.nodes


def test_structural_poison_does_not_propagate_plausible_calls():
    rom = make_lorom_bank0({
        0x8000: bytes([
            0x20, 0x00, 0x90,  # plausible JSR in a poisoned stream
            0x00, 0x00,        # BRK
        ]),
        0x9000: bytes([0x60]),
    })
    manifest = _analyze(rom, ["func Root 8000 entry_mx:1,1"])
    root = manifest.nodes[VariantKey(0x008000, 1, 1)]

    assert root.disposition == NodeDisposition.LLE_ONLY
    assert "structural_poison" in root.reasons
    assert not root.demands
    assert VariantKey(0x009000, 1, 1) not in manifest.nodes


def test_decomp_declared_embedded_data_break_does_not_poison_routine():
    rom = make_lorom_bank0({
        # BCC $8004; embedded BRK/signature data; RTS
        0x8000: bytes([0x90, 0x02, 0x00, 0x00, 0x60]),
    })
    manifest = _analyze(rom, [
        "func Root 8000 entry_mx:1,1",
        "data_region 00 8002 8004",
    ])
    root = manifest.nodes[VariantKey(0x008000, 1, 1)]

    assert root.disposition == NodeDisposition.AOT_ELIGIBLE
    assert "structural_poison" not in root.reasons


def test_decode_budget_classifies_node_lle_only_without_partial_graph():
    rom = make_lorom_bank0({
        0x8000: bytes([0xEA, 0xEA, 0xEA, 0x60]),
    })
    manifest = _analyze(rom, ["func Root 8000 entry_mx:1,1"], max_insns=2)
    node = manifest.nodes[VariantKey(0x008000, 1, 1)]

    assert node.disposition == NodeDisposition.LLE_ONLY
    assert node.reasons == ("decode_budget_exhausted",)
    assert node.instruction_count == 0
    assert not node.demands


def test_invalid_static_target_is_recorded_as_exact_lle_not_enqueued():
    # The image is one 32 KiB bank, so $01:8000 is not code.
    rom = make_lorom_bank0({
        0x8000: bytes([0x22, 0x00, 0x80, 0x01, 0x60]),  # JSL $018000
    })
    root_key = VariantKey(0x008000, 1, 1)
    manifest = _analyze(rom, ["func Root 8000 entry_mx:1,1"])
    edge, = manifest.nodes[root_key].demands

    assert edge.target == VariantKey(0x018000, 1, 1)
    assert edge.resolution == EdgeResolution.LLE_EXACT
    assert edge.target not in manifest.nodes


def test_cross_bank_long_jump_is_an_exact_tail_demand():
    rom = make_lorom_bank0({
        0x8000: bytes([0x5C, 0x00, 0x90, 0x00]),  # JML $009000
        0x9000: bytes([0x60]),
    })
    manifest = _analyze(rom, ["func Root 8000 entry_mx:0,1"])
    edge, = manifest.nodes[VariantKey(0x008000, 0, 1)].demands

    assert edge.kind == EdgeKind.DIRECT_TAIL_CALL
    assert edge.target == VariantKey(0x009000, 0, 1)
    assert edge.target in manifest.nodes
