/* Namespace switches must retain the prior SRAM when publication fails. */
#include "common_rtl.h"
#include <assert.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#define MKDIR(p) _mkdir(p)
#define RMDIR(p) _rmdir(p)
#else
#include <unistd.h>
#define MKDIR(p) mkdir(p,0755)
#define RMDIR(p) rmdir(p)
#endif
static void expect(const char *path, int value) {
  FILE *f=fopen(path,"rb"); assert(f);
  for(int i=0;i<4;++i)assert(fgetc(f)==value);
  assert(fgetc(f)==EOF); assert(!fclose(f));
}
int main(void) {
  uint8 bytes[4]={1,1,1,1};g_sram=bytes;g_sram_size=4;
  RtlSetSaveRoot("sram-test");MKDIR("sram-test");
  remove("sram-test/save.srm");remove("sram-test/save.srm.bak");
  assert(RtlTryWriteSram());expect("sram-test/save.srm",1);
  memset(bytes,2,4);assert(RtlTryWriteSram());
  expect("sram-test/save.srm",2);expect("sram-test/save.srm.bak",1);
  MKDIR("sram-test/save.srm.tmp");memset(bytes,3,4);
  assert(!RtlTryWriteSram());expect("sram-test/save.srm",2);expect("sram-test/save.srm.bak",1);
  /* The public writer must report failure and preserve the last good save,
   * never bypass failed atomic publication with a direct overwrite. */
  assert(!RtlWriteSram());expect("sram-test/save.srm",2);expect("sram-test/save.srm.bak",1);
  RMDIR("sram-test/save.srm.tmp");
  assert(RtlWriteSram());expect("sram-test/save.srm",3);expect("sram-test/save.srm.bak",2);
  /* The explicit writer cannot follow a changed global root or live SRAM.
   * Its immutable caller image and file path are the complete write inputs. */
  uint8 image[4]={9,9,9,9};
  MKDIR("image-test");
  memset(bytes,0xee,4);
  assert(RtlWriteSramImage("image-test/save.srm",image,sizeof(image)));
  expect("image-test/save.srm",9);expect("sram-test/save.srm",3);
  memset(image,8,4);
  assert(RtlWriteSramImage("image-test/save.srm",image,sizeof(image)));
  expect("image-test/save.srm",8);expect("image-test/save.srm.bak",9);
  MKDIR("image-test/save.srm.tmp");
  memset(image,7,4);
  assert(!RtlWriteSramImage("image-test/save.srm",image,sizeof(image)));
  expect("image-test/save.srm",8);expect("image-test/save.srm.bak",9);
  assert(!RtlWriteSramImage(NULL,image,sizeof(image)));
  assert(!RtlWriteSramImage("image-test/save.srm",NULL,4));
  expect("image-test/save.srm",8);
  RMDIR("image-test/save.srm.tmp");
  remove("image-test/save.srm");remove("image-test/save.srm.bak");RMDIR("image-test");
  remove("sram-test/save.srm");remove("sram-test/save.srm.bak");RMDIR("sram-test");
  puts("SRAM publication, backup and failed-write preservation passed");return 0;
}
