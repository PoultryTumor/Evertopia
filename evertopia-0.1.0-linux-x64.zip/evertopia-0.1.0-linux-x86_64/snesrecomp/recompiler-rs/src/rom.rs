//! ROM loading + LoROM/HiROM address mapping, reloc-aware (port of the ROM half of
//! `recompiler/snes65816.py`).
//!
//! Unlike the Python, there is no process-global reloc registry: reloc regions
//! are threaded explicitly (via `DecodeEnv` in later phases) and passed by `&`
//! to the byte-fetch translators here.

use std::io;
use std::path::Path;

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Hash)]
pub enum RomMapping {
    #[default]
    LoRom,
    HiRom,
    Sa1,
    Sdd1ExLoRom,
}

const SDD1_MMC_DEFAULT_PAGES: [usize; 4] = [0, 1, 2, 3];

/// Whole-bank execution-compatible XOR-80 pairs. Never cross low/full HiROM banks.
pub fn execution_mirror_bank(mapping: RomMapping, bank: u32) -> Option<u32> {
    if mapping == RomMapping::HiRom {
        return (!matches!(bank & 0xff, 0x7e | 0x7f | 0xfe | 0xff)).then_some((bank & 0xff) ^ 0x80);
    }
    if mapping == RomMapping::Sa1 {
        return None;
    }
    let bank = bank & 0xFF;
    if bank < 0x40 || (0x80..0xC0).contains(&bank) {
        Some(bank ^ 0x80)
    } else {
        None
    }
}

/// Physical HiROM byte aliases. These do not imply identical execution-bank
/// semantics or permit sharing inferred callee exits across low/full banks.
pub fn hirom_bank_aliases(bank: u32, addr: u32) -> Vec<u32> {
    let bank = bank & 0xff;
    let addr = addr & 0xffff;
    if !is_rom_address(RomMapping::HiRom, bank, addr) {
        return Vec::new();
    }
    let mut result = vec![bank];
    for high in [0, 0x40, 0x80, 0xc0] {
        let candidate = (bank & 0x3f) | high;
        if candidate != bank && is_rom_address(RomMapping::HiRom, candidate, addr) {
            result.push(candidate);
        }
    }
    result
}

fn header_score(data: &[u8], base: usize, expected_low_nibble: u8) -> i32 {
    if base + 0x40 > data.len() {
        return -1;
    }
    let mut score = 0;
    if data[base + 0x15] & 0x0F == expected_low_nibble {
        score += 4;
    }
    let reset = u16::from_le_bytes([data[base + 0x3C], data[base + 0x3D]]);
    if reset >= 0x8000 && reset != 0xFFFF {
        score += 2;
    }
    let complement = u16::from_le_bytes([data[base + 0x1C], data[base + 0x1D]]);
    let checksum = u16::from_le_bytes([data[base + 0x1E], data[base + 0x1F]]);
    if checksum ^ complement == 0xFFFF {
        score += 2;
    }
    score
}

pub fn detect_rom_mapping(data: &[u8]) -> RomMapping {
    if data.len() >= 0x8000 && data[0x7fd5] == 0x23 && matches!(data[0x7fd6], 0x34 | 0x35) {
        return RomMapping::Sa1;
    }
    let lorom_score = header_score(data, 0x7FC0, 0);
    let hirom_score = header_score(data, 0xFFC0, 1);
    if hirom_score > lorom_score {
        RomMapping::HiRom
    } else if data.len() > 0x400000 {
        RomMapping::Sdd1ExLoRom
    } else {
        RomMapping::LoRom
    }
}

pub fn vector_table_offset(data: &[u8]) -> usize {
    match detect_rom_mapping(data) {
        RomMapping::LoRom | RomMapping::Sdd1ExLoRom | RomMapping::Sa1 => 0x7FE0,
        RomMapping::HiRom => 0xFFE0,
    }
}

/// Load a ROM image, stripping a 512-byte copier header if present.
pub fn load_rom<P: AsRef<Path>>(path: P) -> io::Result<Vec<u8>> {
    let data = std::fs::read(path)?;
    if data.len() % 1024 == 512 {
        Ok(data[512..].to_vec())
    } else {
        Ok(data)
    }
}

/// LoROM (bank, addr) -> physical ROM byte offset. `addr` must be in
/// $8000-$FFFF (the Python asserts this).
#[inline]
pub fn lorom_offset(bank: u32, addr: u32) -> usize {
    // Always assert (Python uses a bare `assert`, active in all builds) so an
    // invalid address fails loudly instead of underflowing in release.
    assert!(
        (0x8000..=0xFFFF).contains(&addr),
        "addr ${addr:04X} not in LoROM range $8000-$FFFF"
    );
    ((bank & 0x7F) as usize) * 0x8000 + (addr as usize - 0x8000)
}

pub fn rom_offset(mapping: RomMapping, bank: u32, addr: u32) -> usize {
    let bank = bank & 0xFF;
    let addr = addr & 0xFFFF;
    assert!(
        bank != 0x7E && bank != 0x7F,
        "WRAM address has no ROM offset"
    );
    match mapping {
        RomMapping::Sa1 => {
            if bank >= 0xc0 {
                return (((bank - 0xc0) << 16) | addr) as usize;
            }
            assert!(
                (bank & 0x7f) < 0x40 && addr >= 0x8000,
                "not a SA-1 ROM window"
            );
            ((if bank & 0x80 != 0 { 0x200000 } else { 0 })
                | ((bank & 0x3f) << 15)
                | (addr & 0x7fff)) as usize
        }
        RomMapping::Sdd1ExLoRom if (0xC0..=0xFF).contains(&bank) => {
            let page = SDD1_MMC_DEFAULT_PAGES[((bank >> 4) & 3) as usize];
            let addr24 = ((bank as usize) << 16) | addr as usize;
            (page << 20) | (addr24 & 0xFFFFF)
        }
        RomMapping::Sdd1ExLoRom | RomMapping::LoRom => lorom_offset(bank, addr),
        RomMapping::HiRom => {
            let canonical_bank = bank & 0x7F;
            assert!(
                canonical_bank >= 0x40 || addr >= 0x8000,
                "address ${bank:02X}:{addr:04X} is not in a HiROM ROM window"
            );
            (((canonical_bank & 0x3F) as usize) << 16) | addr as usize
        }
    }
}

pub fn is_rom_address(mapping: RomMapping, bank: u32, addr: u32) -> bool {
    let bank = bank & 0xFF;
    let addr = addr & 0xFFFF;
    if bank == 0x7E || bank == 0x7F {
        return false;
    }
    match mapping {
        RomMapping::Sa1 => bank >= 0xc0 || ((bank & 0x7f) < 0x40 && addr >= 0x8000),
        RomMapping::Sdd1ExLoRom if (0xC0..=0xFF).contains(&bank) => true,
        RomMapping::Sdd1ExLoRom | RomMapping::LoRom => {
            addr >= 0x8000 && !(0x40..0x80).contains(&bank)
        }
        RomMapping::HiRom => (bank & 0x7F) >= 0x40 || addr >= 0x8000,
    }
}

/// A RAM-executed-from-ROM region: the bytes at WRAM `ram_addr..ram_addr+length`
/// (in `ram_bank`) are a linear copy of ROM `rom_off..` (in `rom_bank`). All
/// logical addresses stay at the WRAM execution address; only byte-fetch is
/// redirected to the ROM source. Mirrors the Python 5-tuple
/// `(ram_bank, ram_addr, rom_bank, rom_off, length)`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct RelocRegion {
    pub ram_bank: u8,
    pub ram_addr: u16,
    pub rom_bank: u8,
    pub rom_off: u16,
    pub length: u32,
}

impl RelocRegion {
    pub fn new(ram_bank: u32, ram_addr: u32, rom_bank: u32, rom_off: u32, length: u32) -> Self {
        RelocRegion {
            ram_bank: (ram_bank & 0xFF) as u8,
            ram_addr: (ram_addr & 0xFFFF) as u16,
            rom_bank: (rom_bank & 0xFF) as u8,
            rom_off: (rom_off & 0xFFFF) as u16,
            length,
        }
    }
}

/// Return the matching reloc region for (bank, addr), or `None`. A match means
/// `addr` is in `[ram_addr, ram_addr+length)` for the given `ram_bank`.
pub fn addr_in_reloc_region(bank: u32, addr: u32, regions: &[RelocRegion]) -> Option<RelocRegion> {
    if regions.is_empty() {
        return None;
    }
    let bank = (bank & 0xFF) as u8;
    let addr = addr & 0xFFFF;
    for r in regions {
        if r.ram_bank != bank {
            continue;
        }
        let base = r.ram_addr as u32;
        if base <= addr && addr < base + r.length {
            return Some(*r);
        }
    }
    None
}

/// Map (bank, addr) to a physical ROM byte offset, reloc-aware. If (bank, addr)
/// is inside a registered reloc region, return the ROM offset of the source
/// byte; otherwise fall back to plain `lorom_offset`.
pub fn addr_to_rom_offset(
    mapping: RomMapping,
    bank: u32,
    addr: u32,
    regions: &[RelocRegion],
) -> usize {
    if let Some(r) = addr_in_reloc_region(bank, addr, regions) {
        let delta = (addr & 0xFFFF) - (r.ram_addr as u32);
        return rom_offset(mapping, r.rom_bank as u32, r.rom_off as u32) + delta as usize;
    }
    rom_offset(mapping, bank, addr)
}

/// Borrow a `length`-byte slice of the ROM at LoROM (bank, addr).
pub fn rom_slice(rom: &[u8], bank: u32, addr: u32, length: usize) -> &[u8] {
    let off = lorom_offset(bank, addr);
    let end = (off + length).min(rom.len());
    &rom[off.min(rom.len())..end]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lorom_basic() {
        // bank 0, $8000 -> offset 0
        assert_eq!(lorom_offset(0x00, 0x8000), 0);
        // bank 1, $8000 -> 0x8000
        assert_eq!(lorom_offset(0x01, 0x8000), 0x8000);
        // bank&0x7F masks high bit
        assert_eq!(lorom_offset(0x80, 0x8000), 0);
        // addr offset within bank
        assert_eq!(lorom_offset(0x00, 0xD127), 0xD127 - 0x8000);
    }

    #[test]
    fn reloc_redirect() {
        // Star Fox: $7E:321F <- ROM $02:8000, len 0x5C00-ish.
        let regions = vec![RelocRegion::new(0x7E, 0x321F, 0x02, 0x8000, 0x6000)];
        // Inside the region: $7E:321F maps to ROM offset of $02:8000.
        assert_eq!(
            addr_to_rom_offset(RomMapping::LoRom, 0x7E, 0x321F, &regions),
            lorom_offset(0x02, 0x8000)
        );
        // Offset 0x10 in: maps 0x10 past the ROM base.
        assert_eq!(
            addr_to_rom_offset(RomMapping::LoRom, 0x7E, 0x322F, &regions),
            lorom_offset(0x02, 0x8000) + 0x10
        );
        // Outside the region (different bank) falls back to lorom_offset.
        assert!(addr_in_reloc_region(0x00, 0x8000, &regions).is_none());
    }

    #[test]
    fn mapping_detection_and_hirom_offsets() {
        let mut rom = vec![0u8; 0x10000];
        rom[0xFFD5] = 0x21;
        rom[0xFFFC..0xFFFE].copy_from_slice(&0x84F8u16.to_le_bytes());
        rom[0xFFDC..0xFFDE].copy_from_slice(&0x1234u16.to_le_bytes());
        rom[0xFFDE..0xFFE0].copy_from_slice(&0xEDCBu16.to_le_bytes());
        assert_eq!(detect_rom_mapping(&rom), RomMapping::HiRom);
        assert_eq!(vector_table_offset(&rom), 0xFFE0);
        assert_eq!(rom_offset(RomMapping::HiRom, 0x80, 0x84F8), 0x84F8);
        assert_eq!(rom_offset(RomMapping::HiRom, 0xC0, 0x1234), 0x1234);
        assert_eq!(rom_offset(RomMapping::HiRom, 0xFD, 0x819D), 0x3D819D);
    }

    #[test]
    fn detects_and_maps_sdd1_exlorom_windows() {
        let mut rom = vec![0u8; 0x600000];
        rom[0x7FD5] = 0x32;
        rom[0x7FFC..0x7FFE].copy_from_slice(&0xFEC1u16.to_le_bytes());
        rom[0x7FDC..0x7FDE].copy_from_slice(&0xEC47u16.to_le_bytes());
        rom[0x7FDE..0x7FE0].copy_from_slice(&0x13B8u16.to_le_bytes());
        assert_eq!(detect_rom_mapping(&rom), RomMapping::Sdd1ExLoRom);
        assert_eq!(vector_table_offset(&rom), 0x7FE0);
        assert!(is_rom_address(RomMapping::Sdd1ExLoRom, 0xC0, 0x0000));
        assert!(is_rom_address(RomMapping::Sdd1ExLoRom, 0xFF, 0xFFFF));
        assert_eq!(rom_offset(RomMapping::Sdd1ExLoRom, 0xC0, 0x0000), 0);
        assert_eq!(rom_offset(RomMapping::Sdd1ExLoRom, 0xD0, 0x0000), 0x100000);
        assert_eq!(rom_offset(RomMapping::Sdd1ExLoRom, 0xFF, 0xFFFF), 0x3FFFFF);
        assert_eq!(rom_offset(RomMapping::Sdd1ExLoRom, 0x80, 0x8000), 0);
    }
}
